import React, { Component } from "react";
import books from "../Books/books";
class DescriptioBook extends Component{
    render(){
        return(
            <div>
                Ola
            </div>
        )
    }
}
export default DescriptioBook;