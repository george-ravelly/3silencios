const books = [
	{
		id: 1,
		nome: "o nome do vento",
		autor: "Patrick Ruthfuss",
		lancamento: "2013",
		preco: 51.20
	},
	{
		id: 2,
		nome: "o temor do sabio",
		autor: "Patrick Ruthfuss",
		lancamento: "2015",
		preco: 55.92
	},
	{
		id: 3,
		nome: "a musica do silencio",
		autor: "Patrick Ruthfuss",
		lancamento: "2018",
		preco: 19.99
	},
	
	{
		id: 4,
		nome: "percy jackson e o ladrão de raios",
		autor: "rick riordan",
		lancamento: "2005",
		preco: 35.99
	},	
	{
		id: 5,
		nome: "percy jackson e o mar de monstros",
		autor: "rick riordan",
		lancamento: "2006",
		preco: 35.99
	},
	{
		id: 6,
		nome: "percy jackson e a maldição do titã",
		autor: "rick riordan",
		lancamento: "2007",
		preco: 35.99
	},
	{
		id: 7,
		nome: "percy jackson e a batalha do labirinto",
		autor: "rick riordan",
		lancamento: "2008",
		preco: 35.99
	},
	{
		id: 8,
		nome: "percy jackson e o ultimo olimpiano",
		autor: "rick riordan",
		lancamento: "2010",
		preco: 35.99
	},
	{
		id: 9,
		nome: "jardins da lua - o livro malazano dos caidos 1",
		autor: "steven erickson",
		lancamento: "2017",
		preco: 39.99
	},
	{
		id: 10,
		nome: "os portais da casa dos mortos - o livro malazano dos caidos 2",
		autor: "steven erickson",
		lancamento: "2019",
		preco: 9.99
	},
	{
		id: 11,
		nome: "box - trilogia o senhor dos aneis - 3 volumes",
		autor: "j.r.r. tolkien",
		lancamento: "2019",
		preco: 199.99
	},
	{
		id: 12,
		nome: "a pequena caixa de gwendy",
		autor: "Stephen King",
		lancamento: "2019",
		preco: 31.90
	},
];



export default books;
