import React from "react";

function Rodape() {

    return(
        <footer className="py-4 bg-dark text-white-50 footer-fixed-bottom">
			<div className="container text-center fixed">
				<small>Copyright &copy; George</small>
			</div>
		</footer>
    );
    
} 

export default Rodape;